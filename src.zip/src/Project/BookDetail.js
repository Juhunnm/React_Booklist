import React from 'react';

const BookDetail = () => {
    return (
        <div>
            
        </div>
    );
};

export default BookDetail;